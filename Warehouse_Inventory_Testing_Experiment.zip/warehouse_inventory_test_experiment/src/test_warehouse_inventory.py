import unittest
from warehouse_inventory import WarehouseInventory, InventoryError

class WarehouseInventoryTests(unittest.TestCase):
    def setUp(self):
        self.wh = WarehouseInventory()
        self.wh.add_supplier("SUP-001", "Example Supplies", "inventory@example.com", "9876543210")
        self.wh.add_item("ITM-001", "Safety Gloves", 100)
        self.wh.add_item("ITM-002", "Packing Boxes", 20)

    def test_valid_stock_receipt(self):
        self.assertEqual(self.wh.receive_stock("ITM-001", "SUP-001", 25, "GRN-1001"), 125)

    def test_zero_receipt_rejected_without_changing_stock(self):
        with self.assertRaises(InventoryError):
            self.wh.receive_stock("ITM-001", "SUP-001", 0, "GRN-1001")
        self.assertEqual(self.wh.items["ITM-001"].quantity, 100)

    def test_negative_receipt_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.receive_stock("ITM-001", "SUP-001", -2, "GRN-1001")

    def test_unknown_supplier_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.receive_stock("ITM-001", "SUP-999", 5, "GRN-1001")

    def test_duplicate_receipt_reference_rejected(self):
        self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        with self.assertRaises(InventoryError):
            self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        self.assertEqual(self.wh.items["ITM-001"].quantity, 110)

    def test_valid_issue(self):
        self.assertEqual(self.wh.issue_stock("ITM-001", 30), 70)

    def test_issue_exact_available_stock(self):
        self.assertEqual(self.wh.issue_stock("ITM-002", 20), 0)

    def test_issue_more_than_available_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.issue_stock("ITM-002", 21)
        self.assertEqual(self.wh.items["ITM-002"].quantity, 20)

    def test_zero_issue_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.issue_stock("ITM-001", 0)

    def test_positive_adjustment(self):
        self.assertEqual(self.wh.adjust_stock("ITM-001", 8, "count correction"), 108)

    def test_negative_adjustment(self):
        self.assertEqual(self.wh.adjust_stock("ITM-001", -5, "damaged goods"), 95)

    def test_adjustment_cannot_make_stock_negative(self):
        with self.assertRaises(InventoryError):
            self.wh.adjust_stock("ITM-002", -21, "correction")
        self.assertEqual(self.wh.items["ITM-002"].quantity, 20)

    def test_adjustment_requires_reason(self):
        with self.assertRaises(InventoryError):
            self.wh.adjust_stock("ITM-001", 2, " ")

    def test_add_supplier_valid(self):
        supplier = self.wh.add_supplier("SUP-002", "ABC Supplies", "abc@example.com")
        self.assertEqual(supplier.name, "ABC Supplies")

    def test_duplicate_supplier_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.add_supplier("SUP-001", "Duplicate", "dup@example.com")

    def test_invalid_supplier_email_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.add_supplier("SUP-003", "Bad Email", "supplier-at-example.com")

    def test_supplier_update(self):
        supplier = self.wh.update_supplier("SUP-001", phone="9999999999")
        self.assertEqual(supplier.phone, "9999999999")

    def test_reconciliation_matching_count(self):
        variance, new_qty = self.wh.reconcile("ITM-001", 100, "cycle count")
        self.assertEqual((variance, new_qty), (0, 100))

    def test_reconciliation_shortage(self):
        variance, new_qty = self.wh.reconcile("ITM-001", 96, "cycle count shortage")
        self.assertEqual((variance, new_qty), (-4, 96))

    def test_reconciliation_surplus(self):
        variance, new_qty = self.wh.reconcile("ITM-001", 105, "cycle count surplus")
        self.assertEqual((variance, new_qty), (5, 105))

    def test_negative_physical_count_rejected(self):
        with self.assertRaises(InventoryError):
            self.wh.reconcile("ITM-001", -1, "invalid count")
        self.assertEqual(self.wh.items["ITM-001"].quantity, 100)

    def test_reconciliation_requires_reason(self):
        with self.assertRaises(InventoryError):
            self.wh.reconcile("ITM-001", 99, "")
        self.assertEqual(self.wh.items["ITM-001"].quantity, 100)

if __name__ == "__main__":
    unittest.main(verbosity=2)
