from warehouse_inventory import WarehouseInventory

def main():
    warehouse = WarehouseInventory()
    warehouse.add_supplier("SUP-001", "Example Industrial Supplies", "inventory@example.com")
    warehouse.add_item("ITM-001", "Safety Gloves", 100)
    print("Opening stock:", warehouse.items["ITM-001"].quantity)
    print("After receipt of 25:", warehouse.receive_stock("ITM-001", "SUP-001", 25, "GRN-1001"))
    print("After issue of 30:", warehouse.issue_stock("ITM-001", 30))
    print("After adjustment +5:", warehouse.adjust_stock("ITM-001", 5, "count correction"))
    variance, final_qty = warehouse.reconcile("ITM-001", 98, "physical stock count")
    print(f"Reconciliation variance: {variance}; final stock: {final_qty}")
    print("Transaction history:")
    for transaction in warehouse.transactions:
        print(transaction)

if __name__ == "__main__":
    main()
