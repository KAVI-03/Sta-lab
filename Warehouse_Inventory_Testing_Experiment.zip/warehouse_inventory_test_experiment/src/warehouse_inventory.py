"""Educational warehouse inventory reference implementation.""" 
from dataclasses import dataclass
import re

class InventoryError(ValueError):
    """Raised when a transaction violates an inventory business rule."""

@dataclass
class Supplier:
    code: str
    name: str
    email: str
    phone: str = ""

@dataclass
class Item:
    code: str
    name: str
    quantity: int = 0

class WarehouseInventory:
    def __init__(self):
        self.items = {}
        self.suppliers = {}
        self.receipt_refs = set()
        self.transactions = []

    def add_item(self, code, name, opening_quantity=0):
        code, name = code.strip(), name.strip()
        if not code or not name:
            raise InventoryError("Item code and name are required")
        if code in self.items:
            raise InventoryError("Duplicate item code")
        if not isinstance(opening_quantity, int) or opening_quantity < 0:
            raise InventoryError("Opening quantity must be a non-negative integer")
        self.items[code] = Item(code, name, opening_quantity)

    def add_supplier(self, code, name, email, phone=""):
        code, name, email = code.strip(), name.strip(), email.strip()
        if not code or not name:
            raise InventoryError("Supplier code and name are required")
        if code in self.suppliers:
            raise InventoryError("Duplicate supplier code")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise InventoryError("Valid supplier email is required")
        self.suppliers[code] = Supplier(code, name, email, phone.strip())
        return self.suppliers[code]

    def update_supplier(self, code, name=None, email=None, phone=None):
        if code not in self.suppliers:
            raise InventoryError("Unknown supplier")
        supplier = self.suppliers[code]
        new_name = supplier.name if name is None else name.strip()
        new_email = supplier.email if email is None else email.strip()
        new_phone = supplier.phone if phone is None else phone.strip()
        if not new_name:
            raise InventoryError("Supplier name is required")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", new_email):
            raise InventoryError("Valid supplier email is required")
        supplier.name, supplier.email, supplier.phone = new_name, new_email, new_phone
        return supplier

    def _item(self, code):
        if code not in self.items:
            raise InventoryError("Unknown item")
        return self.items[code]

    @staticmethod
    def _positive_quantity(quantity):
        if not isinstance(quantity, int) or quantity <= 0:
            raise InventoryError("Quantity must be a positive integer")

    def receive_stock(self, item_code, supplier_code, quantity, reference):
        item = self._item(item_code)
        if supplier_code not in self.suppliers:
            raise InventoryError("Unknown supplier")
        self._positive_quantity(quantity)
        reference = reference.strip()
        if not reference:
            raise InventoryError("Receipt reference is required")
        if reference in self.receipt_refs:
            raise InventoryError("Duplicate receipt reference")
        item.quantity += quantity
        self.receipt_refs.add(reference)
        self.transactions.append({"type":"RECEIPT","item":item_code,"quantity":quantity,"reference":reference})
        return item.quantity

    def issue_stock(self, item_code, quantity, reference=""):
        item = self._item(item_code)
        self._positive_quantity(quantity)
        if quantity > item.quantity:
            raise InventoryError("Insufficient stock")
        item.quantity -= quantity
        self.transactions.append({"type":"ISSUE","item":item_code,"quantity":quantity,"reference":reference})
        return item.quantity

    def adjust_stock(self, item_code, delta, reason):
        item = self._item(item_code)
        if not isinstance(delta, int) or delta == 0:
            raise InventoryError("Adjustment must be a non-zero integer")
        if not reason or not reason.strip():
            raise InventoryError("Adjustment reason is required")
        if item.quantity + delta < 0:
            raise InventoryError("Adjustment cannot create negative stock")
        item.quantity += delta
        self.transactions.append({"type":"ADJUSTMENT","item":item_code,"quantity":delta,"reason":reason.strip()})
        return item.quantity

    def reconcile(self, item_code, physical_quantity, reason):
        item = self._item(item_code)
        if not isinstance(physical_quantity, int) or physical_quantity < 0:
            raise InventoryError("Physical count must be a non-negative integer")
        if not reason or not reason.strip():
            raise InventoryError("Reconciliation reason is required")
        variance = physical_quantity - item.quantity
        old_quantity = item.quantity
        item.quantity = physical_quantity
        self.transactions.append({"type":"RECONCILIATION","item":item_code,"system_before":old_quantity,
                                  "physical":physical_quantity,"variance":variance,"reason":reason.strip()})
        return variance, item.quantity
