@echo off
python -m unittest discover -s src -p "test_*.py" -v
pause
