#!/usr/bin/env bash
python3 -m unittest discover -s src -p 'test_*.py' -v
