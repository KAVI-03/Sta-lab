"""
Automated test cases for the Warehouse Inventory Application.

Every test method is named  test_<MODULE>_<NN>_<description>  and matches one row of
test_cases/Test_Cases.csv (for example test_SR_01_... is test case SR-01).

Run:  python run_tests.py        (from the project folder)
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from warehouse_inventory import InventoryError, WarehouseInventory  # noqa: E402


class InventoryTestCase(unittest.TestCase):
    """Common test data: 1 active supplier and 3 items (100, 20 and 0 units)."""

    def setUp(self):
        self.wh = WarehouseInventory()
        self.wh.add_supplier("SUP-001", "Example Industrial Supplies",
                             "inventory@example.com", "9876543210")
        self.wh.add_item("ITM-001", "Safety Gloves", 100)
        self.wh.add_item("ITM-002", "Packing Boxes", 20)
        self.wh.add_item("ITM-003", "Pallet Wrap", 0)

    def assert_stock(self, item_code, expected):
        self.assertEqual(self.wh.get_stock(item_code), expected)


# ----------------------------------------------------------------------
# Supplier Details
# ----------------------------------------------------------------------
class SupplierDetailsTests(InventoryTestCase):

    def test_SD_01_add_valid_supplier(self):
        saved = self.wh.add_supplier("SUP-002", "ABC Supplies", "abc@example.com", "9876501234")
        self.assertTrue(saved["active"])
        stored = self.wh.get_supplier("SUP-002")
        self.assertEqual(stored["name"], "ABC Supplies")
        self.assertEqual(stored["email"], "abc@example.com")
        self.assertEqual(stored["phone"], "9876501234")

    def test_SD_02_add_supplier_without_phone(self):
        self.wh.add_supplier("SUP-002", "ABC Supplies", "abc@example.com")
        self.assertEqual(self.wh.get_supplier("SUP-002")["phone"], "")

    def test_SD_03_duplicate_supplier_code(self):
        with self.assertRaisesRegex(InventoryError, "Duplicate supplier code"):
            self.wh.add_supplier("SUP-001", "Another Name", "other@example.com")
        self.assertEqual(self.wh.get_supplier("SUP-001")["name"], "Example Industrial Supplies")

    def test_SD_04_blank_supplier_code(self):
        with self.assertRaisesRegex(InventoryError, "Supplier code is required"):
            self.wh.add_supplier("   ", "ABC Supplies", "abc@example.com")

    def test_SD_05_blank_supplier_name(self):
        with self.assertRaisesRegex(InventoryError, "Supplier name is required"):
            self.wh.add_supplier("SUP-003", "", "abc@example.com")

    def test_SD_06_invalid_supplier_email(self):
        with self.assertRaisesRegex(InventoryError, "Valid supplier email is required"):
            self.wh.add_supplier("SUP-003", "Bad Email Ltd", "supplier-at-example.com")
        self.assertNotIn("SUP-003", self.wh.suppliers)

    def test_SD_07_phone_length_boundary(self):
        for phone in ("987654321", "98765432101"):      # 9 digits and 11 digits
            with self.assertRaisesRegex(InventoryError, "exactly 10 digits"):
                self.wh.add_supplier("SUP-003", "Phone Test", "abc@example.com", phone)
        self.assertNotIn("SUP-003", self.wh.suppliers)

    def test_SD_08_phone_with_letters(self):
        with self.assertRaisesRegex(InventoryError, "exactly 10 digits"):
            self.wh.add_supplier("SUP-003", "Phone Test", "abc@example.com", "98765ABC10")

    def test_SD_09_update_supplier_phone_and_email(self):
        updated = self.wh.update_supplier("SUP-001", phone="9999999999", email="new@example.com")
        self.assertEqual(updated["phone"], "9999999999")
        stored = self.wh.get_supplier("SUP-001")
        self.assertEqual(stored["email"], "new@example.com")
        self.assertEqual(stored["name"], "Example Industrial Supplies")

    def test_SD_10_update_with_invalid_email(self):
        with self.assertRaisesRegex(InventoryError, "Valid supplier email is required"):
            self.wh.update_supplier("SUP-001", email="bad-email")
        self.assertEqual(self.wh.get_supplier("SUP-001")["email"], "inventory@example.com")

    def test_SD_11_update_unknown_supplier(self):
        with self.assertRaisesRegex(InventoryError, "Unknown supplier"):
            self.wh.update_supplier("SUP-999", phone="9999999999")

    def test_SD_12_deactivate_supplier(self):
        self.wh.deactivate_supplier("SUP-001")
        stored = self.wh.get_supplier("SUP-001")
        self.assertFalse(stored["active"])
        self.assertEqual(stored["email"], "inventory@example.com")


# ----------------------------------------------------------------------
# Stock Receipt
# ----------------------------------------------------------------------
class StockReceiptTests(InventoryTestCase):

    def test_SR_01_valid_stock_receipt(self):
        self.assertEqual(self.wh.receive_stock("ITM-001", "SUP-001", 25, "GRN-1001"), 125)
        self.assert_stock("ITM-001", 125)
        log = self.wh.get_transactions()
        self.assertEqual(len(log), 1)
        self.assertEqual(log[0]["type"], "RECEIPT")
        self.assertEqual(log[0]["reference"], "GRN-1001")
        self.assertEqual(log[0]["quantity"], 25)

    def test_SR_02_receive_minimum_quantity(self):
        self.assertEqual(self.wh.receive_stock("ITM-001", "SUP-001", 1, "GRN-1002"), 101)

    def test_SR_03_receive_zero_quantity(self):
        with self.assertRaisesRegex(InventoryError, "positive whole number"):
            self.wh.receive_stock("ITM-001", "SUP-001", 0, "GRN-1001")
        self.assert_stock("ITM-001", 100)

    def test_SR_04_receive_negative_quantity(self):
        with self.assertRaisesRegex(InventoryError, "positive whole number"):
            self.wh.receive_stock("ITM-001", "SUP-001", -5, "GRN-1001")
        self.assert_stock("ITM-001", 100)

    def test_SR_05_receive_non_whole_quantity(self):
        for quantity in (2.5, "10"):
            with self.assertRaisesRegex(InventoryError, "positive whole number"):
                self.wh.receive_stock("ITM-001", "SUP-001", quantity, "GRN-1001")
        self.assert_stock("ITM-001", 100)

    def test_SR_06_receive_for_unknown_item(self):
        with self.assertRaisesRegex(InventoryError, "Unknown item"):
            self.wh.receive_stock("ITM-999", "SUP-001", 10, "GRN-1001")
        self.assertNotIn("ITM-999", self.wh.items)

    def test_SR_07_receive_from_unknown_supplier(self):
        with self.assertRaisesRegex(InventoryError, "Unknown supplier"):
            self.wh.receive_stock("ITM-001", "SUP-999", 10, "GRN-1001")
        self.assert_stock("ITM-001", 100)

    def test_SR_08_receive_from_inactive_supplier(self):
        self.wh.deactivate_supplier("SUP-001")
        with self.assertRaisesRegex(InventoryError, "Supplier is inactive"):
            self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        self.assert_stock("ITM-001", 100)

    def test_SR_09_receipt_without_reference(self):
        with self.assertRaisesRegex(InventoryError, "Receipt reference is required"):
            self.wh.receive_stock("ITM-001", "SUP-001", 10, "   ")
        self.assert_stock("ITM-001", 100)

    def test_SR_10_duplicate_receipt_reference(self):
        self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        with self.assertRaisesRegex(InventoryError, "Duplicate receipt reference"):
            self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        self.assert_stock("ITM-001", 110)

    def test_SR_11_two_receipts_accumulate(self):
        self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        self.wh.receive_stock("ITM-001", "SUP-001", 15, "GRN-1002")
        self.assert_stock("ITM-001", 125)
        self.assertEqual([t["type"] for t in self.wh.get_transactions()], ["RECEIPT", "RECEIPT"])


# ----------------------------------------------------------------------
# Stock Issue
# ----------------------------------------------------------------------
class StockIssueTests(InventoryTestCase):

    def test_SI_01_valid_stock_issue(self):
        self.assertEqual(self.wh.issue_stock("ITM-001", 30, "Production Line 1"), 70)
        log = self.wh.get_transactions()
        self.assertEqual(len(log), 1)
        self.assertEqual(log[0]["type"], "ISSUE")
        self.assertEqual(log[0]["issued_to"], "Production Line 1")

    def test_SI_02_issue_exactly_available_stock(self):
        self.assertEqual(self.wh.issue_stock("ITM-002", 20, "Dispatch"), 0)

    def test_SI_03_issue_one_more_than_available(self):
        with self.assertRaisesRegex(InventoryError, "Insufficient stock"):
            self.wh.issue_stock("ITM-002", 21, "Dispatch")
        self.assert_stock("ITM-002", 20)

    def test_SI_04_issue_zero_quantity(self):
        with self.assertRaisesRegex(InventoryError, "positive whole number"):
            self.wh.issue_stock("ITM-001", 0, "Dispatch")
        self.assert_stock("ITM-001", 100)

    def test_SI_05_issue_negative_quantity(self):
        with self.assertRaisesRegex(InventoryError, "positive whole number"):
            self.wh.issue_stock("ITM-001", -3, "Dispatch")
        self.assert_stock("ITM-001", 100)

    def test_SI_06_issue_non_whole_quantity(self):
        with self.assertRaisesRegex(InventoryError, "positive whole number"):
            self.wh.issue_stock("ITM-001", 1.5, "Dispatch")
        self.assert_stock("ITM-001", 100)

    def test_SI_07_issue_unknown_item(self):
        with self.assertRaisesRegex(InventoryError, "Unknown item"):
            self.wh.issue_stock("ITM-999", 5, "Dispatch")

    def test_SI_08_issue_without_issued_to(self):
        with self.assertRaisesRegex(InventoryError, "Issued-to"):
            self.wh.issue_stock("ITM-001", 5, "   ")
        self.assert_stock("ITM-001", 100)

    def test_SI_09_issue_from_zero_stock_item(self):
        with self.assertRaisesRegex(InventoryError, "Insufficient stock"):
            self.wh.issue_stock("ITM-003", 1, "Dispatch")
        self.assert_stock("ITM-003", 0)

    def test_SI_10_sequential_issues_down_to_zero(self):
        self.assertEqual(self.wh.issue_stock("ITM-002", 5, "Dept A"), 15)
        self.assertEqual(self.wh.issue_stock("ITM-002", 5, "Dept B"), 10)
        self.assertEqual(self.wh.issue_stock("ITM-002", 10, "Dept C"), 0)


# ----------------------------------------------------------------------
# Inventory Adjustment
# ----------------------------------------------------------------------
class InventoryAdjustmentTests(InventoryTestCase):

    def test_IA_01_positive_adjustment_with_reason(self):
        self.assertEqual(self.wh.adjust_stock("ITM-001", 8, "Count correction"), 108)

    def test_IA_02_negative_adjustment_with_reason(self):
        self.assertEqual(self.wh.adjust_stock("ITM-001", -5, "Damaged goods"), 95)

    def test_IA_03_adjust_stock_exactly_to_zero(self):
        self.assertEqual(self.wh.adjust_stock("ITM-002", -20, "Write-off"), 0)

    def test_IA_04_adjust_below_zero(self):
        with self.assertRaisesRegex(InventoryError, "negative"):
            self.wh.adjust_stock("ITM-002", -21, "Write-off")
        self.assert_stock("ITM-002", 20)

    def test_IA_05_zero_adjustment(self):
        with self.assertRaisesRegex(InventoryError, "non-zero whole number"):
            self.wh.adjust_stock("ITM-001", 0, "No change")
        self.assert_stock("ITM-001", 100)

    def test_IA_06_adjustment_without_reason(self):
        with self.assertRaisesRegex(InventoryError, "reason is required"):
            self.wh.adjust_stock("ITM-001", 2, "   ")
        self.assert_stock("ITM-001", 100)

    def test_IA_07_non_whole_adjustment(self):
        with self.assertRaisesRegex(InventoryError, "non-zero whole number"):
            self.wh.adjust_stock("ITM-001", 2.5, "Count")
        self.assert_stock("ITM-001", 100)

    def test_IA_08_adjust_unknown_item(self):
        with self.assertRaisesRegex(InventoryError, "Unknown item"):
            self.wh.adjust_stock("ITM-999", 3, "Count")

    def test_IA_09_adjustment_is_recorded_with_reason(self):
        self.wh.adjust_stock("ITM-001", -5, "Damaged goods")
        log = self.wh.get_transactions()
        self.assertEqual(len(log), 1)
        self.assertEqual(log[0]["type"], "ADJUSTMENT")
        self.assertEqual(log[0]["quantity"], -5)
        self.assertEqual(log[0]["reason"], "Damaged goods")


# ----------------------------------------------------------------------
# Stock Reconciliation
# ----------------------------------------------------------------------
class StockReconciliationTests(InventoryTestCase):

    def test_RC_01_physical_count_matches_system(self):
        result = self.wh.reconcile("ITM-001", 100, "Cycle count")
        self.assertEqual(result["variance"], 0)
        self.assertEqual(result["status"], "MATCH")
        self.assert_stock("ITM-001", 100)

    def test_RC_02_shortage_found(self):
        result = self.wh.reconcile("ITM-001", 96, "Cycle count")
        self.assertEqual(result["variance"], -4)
        self.assertEqual(result["status"], "SHORTAGE")
        self.assert_stock("ITM-001", 96)

    def test_RC_03_surplus_found(self):
        result = self.wh.reconcile("ITM-001", 105, "Cycle count")
        self.assertEqual(result["variance"], 5)
        self.assertEqual(result["status"], "SURPLUS")
        self.assert_stock("ITM-001", 105)

    def test_RC_04_physical_count_of_zero(self):
        result = self.wh.reconcile("ITM-001", 0, "Item missing")
        self.assertEqual(result["variance"], -100)
        self.assertEqual(result["status"], "SHORTAGE")
        self.assert_stock("ITM-001", 0)

    def test_RC_05_negative_physical_count(self):
        with self.assertRaisesRegex(InventoryError, "non-negative whole number"):
            self.wh.reconcile("ITM-001", -1, "Cycle count")
        self.assert_stock("ITM-001", 100)

    def test_RC_06_non_whole_physical_count(self):
        with self.assertRaisesRegex(InventoryError, "non-negative whole number"):
            self.wh.reconcile("ITM-001", 10.5, "Cycle count")
        self.assert_stock("ITM-001", 100)

    def test_RC_07_reconcile_unknown_item(self):
        with self.assertRaisesRegex(InventoryError, "Unknown item"):
            self.wh.reconcile("ITM-999", 10, "Cycle count")

    def test_RC_08_reconciliation_without_reason(self):
        with self.assertRaisesRegex(InventoryError, "reason is required"):
            self.wh.reconcile("ITM-001", 99, "")
        self.assert_stock("ITM-001", 100)

    def test_RC_09_reconciliation_is_recorded(self):
        self.wh.reconcile("ITM-001", 98, "Cycle count")
        log = self.wh.get_transactions()
        self.assertEqual(len(log), 1)
        self.assertEqual(log[0]["type"], "RECONCILIATION")
        self.assertEqual(log[0]["system_before"], 100)
        self.assertEqual(log[0]["physical"], 98)
        self.assertEqual(log[0]["variance"], -2)


# ----------------------------------------------------------------------
# Integration / General rules
# ----------------------------------------------------------------------
class IntegrationTests(InventoryTestCase):

    def test_IT_01_end_to_end_stock_flow(self):
        self.assertEqual(self.wh.receive_stock("ITM-001", "SUP-001", 25, "GRN-1001"), 125)
        self.assertEqual(self.wh.issue_stock("ITM-001", 30, "Production Line 1"), 95)
        self.assertEqual(self.wh.adjust_stock("ITM-001", 5, "Count correction"), 100)
        result = self.wh.reconcile("ITM-001", 98, "Physical stock count")
        self.assertEqual(result["variance"], -2)
        self.assert_stock("ITM-001", 98)
        self.assertEqual([t["type"] for t in self.wh.get_transactions()],
                         ["RECEIPT", "ISSUE", "ADJUSTMENT", "RECONCILIATION"])

    def test_IT_02_rejected_transactions_change_nothing(self):
        before = {code: self.wh.get_stock(code) for code in self.wh.items}
        with self.assertRaises(InventoryError):
            self.wh.receive_stock("ITM-001", "SUP-001", -1, "GRN-1001")
        with self.assertRaises(InventoryError):
            self.wh.issue_stock("ITM-002", 999, "Dispatch")
        with self.assertRaises(InventoryError):
            self.wh.adjust_stock("ITM-003", -1, "Write-off")
        with self.assertRaises(InventoryError):
            self.wh.reconcile("ITM-001", -5, "Cycle count")
        after = {code: self.wh.get_stock(code) for code in self.wh.items}
        self.assertEqual(before, after)
        self.assertEqual(self.wh.receipt_refs, set())
        self.assertEqual(self.wh.get_transactions(), [])

    def test_IT_03_transaction_ids_unique_and_sequential(self):
        self.wh.receive_stock("ITM-001", "SUP-001", 10, "GRN-1001")
        self.wh.issue_stock("ITM-001", 5, "Dispatch")
        self.wh.adjust_stock("ITM-001", 1, "Count correction")
        ids = [t["txn_id"] for t in self.wh.get_transactions()]
        self.assertEqual(ids, ["TXN-0001", "TXN-0002", "TXN-0003"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
