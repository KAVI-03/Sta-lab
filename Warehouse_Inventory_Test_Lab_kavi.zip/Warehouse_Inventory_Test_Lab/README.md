# Warehouse Inventory Application - Test Plan and Test Cases

**Question:** Design a test plan and test cases for a warehouse inventory application
covering stock receipt, stock issue, inventory adjustment, supplier details and stock
reconciliation.

This package answers the question completely: a written test plan, 54 test cases, the
application, automated tests, and an execution report with real results.

## What is inside

```
Warehouse_Inventory_Test_Lab/
|-- README.md                          this file
|-- run_tests.py                       runs all test cases, prints results, writes the report
|-- run_tests.bat / run_tests.sh       one-click runners (Windows / Linux, macOS)
|-- docs/
|   `-- Test_Plan_and_Test_Cases.docx  TEST PLAN + test cases + traceability + results (11 pages)
|-- test_cases/
|   |-- Test_Cases.csv                 the 54 test cases (open in Excel)
|   `-- Sample_Test_Data.csv           valid and invalid test data
|-- src/
|   `-- warehouse_inventory.py         the application (5 modules)
|-- tests/
|   `-- test_warehouse_inventory.py    one automated test per test case (SD-01 ... IT-03)
`-- results/
    `-- Test_Execution_Report.csv      actual result and status of every test case
```

## How to run

Needs Python 3.8 or later. Nothing else to install.

```
Windows:          python run_tests.py        (or double-click run_tests.bat)
Linux / macOS:    python3 run_tests.py       (or ./run_tests.sh)
```

Add your name to the report: `python run_tests.py --tester "Your Name"`

Expected output ends with:

```
TOTAL                        54     54      0      0
Pass rate: 100.0%
RESULT: ALL TEST CASES PASSED
```

## How to write the answer in the lab

1. **Aim** - To design a test plan and test cases for a warehouse inventory application
   and execute them.
2. **Test plan** - write the headings from `docs/Test_Plan_and_Test_Cases.docx`, sections 1 to 9:
   introduction, objectives, scope (in / out), requirements, test approach (techniques),
   environment, test data, entry / exit / suspension criteria, deliverables, defect severity,
   risks.
3. **Test cases** - copy the table (section 10.1 of the document or `Test_Cases.csv`):
   ID, module, type, priority, preconditions, input, expected result. 54 cases:
   Supplier Details 12, Stock Receipt 11, Stock Issue 10, Inventory Adjustment 9,
   Stock Reconciliation 9, Integration 3.
4. **Program** - `src/warehouse_inventory.py` (application) and
   `tests/test_warehouse_inventory.py` (test code).
5. **Output** - run `python run_tests.py` and take a screenshot of the result table.
6. **Result** - "All 54 test cases were executed and passed. Every requirement is covered
   by at least one test case."

## Business rules the application enforces (and the tests check)

- Quantities are whole numbers above zero (receipt, issue); adjustment is a non-zero whole number.
- Stock never becomes negative (issue, adjustment).
- A receipt needs an existing, active supplier and a unique receipt reference (GRN).
- Issue needs "issued to"; adjustment and reconciliation need a reason.
- Supplier phone (optional) is exactly 10 digits; email must be valid.
- Reconciliation: variance = physical count - system stock; stock is set to the physical count.
- A rejected transaction changes nothing; every successful one is logged (TXN-0001, TXN-0002, ...).

## Quick viva answers

- **Test plan** - a document that says what will be tested, how, with what, and when testing
  starts and stops. **Test case** - one specific input with its expected result.
- **Equivalence partitioning** - group inputs into valid and invalid classes and test one from
  each (quantity: 25 valid; 0, -5, 2.5 invalid).
- **Boundary value analysis** - test on and next to the limit (stock 20: issue 20 passes,
  issue 21 is rejected).
- **Positive vs negative test** - positive uses valid data and expects success; negative uses
  invalid data and expects a rejection.
- **Why reject a duplicate receipt reference?** - the same delivery must not be counted twice.
- **Stock reconciliation** - comparing the physical count with the system stock; the difference
  is the variance (negative = shortage, positive = surplus).
- **Traceability matrix** - a table linking each requirement to the test cases that verify it
  (section 11 of the document).
