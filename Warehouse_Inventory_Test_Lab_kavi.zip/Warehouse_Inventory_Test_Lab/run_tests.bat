@echo off
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
    python run_tests.py %*
) else (
    py run_tests.py %*
)
pause
