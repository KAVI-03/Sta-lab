"""
Warehouse Inventory Application
===============================
A small, self-contained inventory model used for the software testing lab.

Modules
  1. Supplier Details       - add / view / update / deactivate suppliers
  2. Stock Receipt          - goods received from a supplier (GRN)
  3. Stock Issue            - goods issued out of the warehouse
  4. Inventory Adjustment   - manual correction (+/-) with a mandatory reason
  5. Stock Reconciliation   - compare physical count with system stock

Business rules enforced
  * Quantities must be whole numbers (decimals, text and True/False are rejected).
  * Stock can never become negative.
  * A receipt needs a known, ACTIVE supplier and a unique receipt reference.
  * Adjustments and reconciliations need a reason (audit trail).
  * A rejected transaction changes nothing: stock and the log stay as they were.
"""
import re
from datetime import datetime

EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
PHONE_RE = re.compile(r"[0-9]{10}")


class InventoryError(ValueError):
    """Raised when an operation breaks a business rule."""


def _is_whole_number(value):
    # bool is a subclass of int in Python, so it is excluded explicitly
    return isinstance(value, int) and not isinstance(value, bool)


def _text(value):
    return value.strip() if isinstance(value, str) else ""


def _phone_text(value):
    return "" if value is None else str(value).strip()


class WarehouseInventory:
    def __init__(self):
        self.items = {}           # item code     -> {"code", "name", "quantity"}
        self.suppliers = {}       # supplier code -> {"code", "name", "email", "phone", "active"}
        self.receipt_refs = set()  # receipt references already used
        self.transactions = []    # audit log of successful transactions

    # ------------------------------------------------------------------
    # Item master (needed so that stock can be received / issued)
    # ------------------------------------------------------------------
    def add_item(self, code, name, opening_quantity=0):
        code, name = _text(code), _text(name)
        if not code or not name:
            raise InventoryError("Item code and name are required")
        if code in self.items:
            raise InventoryError("Duplicate item code")
        if not _is_whole_number(opening_quantity) or opening_quantity < 0:
            raise InventoryError("Opening quantity must be a non-negative whole number")
        self.items[code] = {"code": code, "name": name, "quantity": opening_quantity}
        return dict(self.items[code])

    def _item(self, code):
        if code not in self.items:
            raise InventoryError("Unknown item")
        return self.items[code]

    def get_stock(self, item_code):
        return self._item(item_code)["quantity"]

    # ------------------------------------------------------------------
    # 1. Supplier details
    # ------------------------------------------------------------------
    @staticmethod
    def _check_contact(email, phone):
        if not EMAIL_RE.fullmatch(email):
            raise InventoryError("Valid supplier email is required")
        if phone and not PHONE_RE.fullmatch(phone):
            raise InventoryError("Phone number must be exactly 10 digits")

    def _supplier(self, code):
        if code not in self.suppliers:
            raise InventoryError("Unknown supplier")
        return self.suppliers[code]

    def add_supplier(self, code, name, email, phone=""):
        code, name, email = _text(code), _text(name), _text(email)
        phone = _phone_text(phone)
        if not code:
            raise InventoryError("Supplier code is required")
        if not name:
            raise InventoryError("Supplier name is required")
        if code in self.suppliers:
            raise InventoryError("Duplicate supplier code")
        self._check_contact(email, phone)
        self.suppliers[code] = {"code": code, "name": name, "email": email,
                                "phone": phone, "active": True}
        return dict(self.suppliers[code])

    def get_supplier(self, code):
        return dict(self._supplier(code))

    def update_supplier(self, code, name=None, email=None, phone=None):
        supplier = self._supplier(code)
        new_name = supplier["name"] if name is None else _text(name)
        new_email = supplier["email"] if email is None else _text(email)
        new_phone = supplier["phone"] if phone is None else _phone_text(phone)
        if not new_name:
            raise InventoryError("Supplier name is required")
        self._check_contact(new_email, new_phone)   # validate everything before saving
        supplier.update(name=new_name, email=new_email, phone=new_phone)
        return dict(supplier)

    def deactivate_supplier(self, code):
        supplier = self._supplier(code)
        supplier["active"] = False
        return dict(supplier)

    # ------------------------------------------------------------------
    # Helpers shared by the stock transactions
    # ------------------------------------------------------------------
    @staticmethod
    def _positive_quantity(quantity):
        if not _is_whole_number(quantity) or quantity <= 0:
            raise InventoryError("Quantity must be a positive whole number")

    def _log(self, kind, **details):
        entry = {"txn_id": "TXN-%04d" % (len(self.transactions) + 1),
                 "type": kind,
                 "time": datetime.now().isoformat(timespec="seconds")}
        entry.update(details)
        self.transactions.append(entry)
        return entry

    def get_transactions(self):
        return list(self.transactions)

    # ------------------------------------------------------------------
    # 2. Stock receipt
    # ------------------------------------------------------------------
    def receive_stock(self, item_code, supplier_code, quantity, reference):
        item = self._item(item_code)
        supplier = self._supplier(supplier_code)
        if not supplier["active"]:
            raise InventoryError("Supplier is inactive")
        self._positive_quantity(quantity)
        reference = _text(reference)
        if not reference:
            raise InventoryError("Receipt reference is required")
        if reference in self.receipt_refs:
            raise InventoryError("Duplicate receipt reference")
        item["quantity"] += quantity
        self.receipt_refs.add(reference)
        self._log("RECEIPT", item=item_code, supplier=supplier_code, quantity=quantity,
                  reference=reference, stock_after=item["quantity"])
        return item["quantity"]

    # ------------------------------------------------------------------
    # 3. Stock issue
    # ------------------------------------------------------------------
    def issue_stock(self, item_code, quantity, issued_to):
        item = self._item(item_code)
        self._positive_quantity(quantity)
        issued_to = _text(issued_to)
        if not issued_to:
            raise InventoryError("Issued-to (department or person) is required")
        if quantity > item["quantity"]:
            raise InventoryError("Insufficient stock")
        item["quantity"] -= quantity
        self._log("ISSUE", item=item_code, quantity=quantity, issued_to=issued_to,
                  stock_after=item["quantity"])
        return item["quantity"]

    # ------------------------------------------------------------------
    # 4. Inventory adjustment
    # ------------------------------------------------------------------
    def adjust_stock(self, item_code, delta, reason):
        item = self._item(item_code)
        if not _is_whole_number(delta) or delta == 0:
            raise InventoryError("Adjustment must be a non-zero whole number")
        reason = _text(reason)
        if not reason:
            raise InventoryError("Adjustment reason is required")
        if item["quantity"] + delta < 0:
            raise InventoryError("Adjustment would make stock negative")
        item["quantity"] += delta
        self._log("ADJUSTMENT", item=item_code, quantity=delta, reason=reason,
                  stock_after=item["quantity"])
        return item["quantity"]

    # ------------------------------------------------------------------
    # 5. Stock reconciliation
    # ------------------------------------------------------------------
    def reconcile(self, item_code, physical_quantity, reason):
        item = self._item(item_code)
        if not _is_whole_number(physical_quantity) or physical_quantity < 0:
            raise InventoryError("Physical count must be a non-negative whole number")
        reason = _text(reason)
        if not reason:
            raise InventoryError("Reconciliation reason is required")
        system_before = item["quantity"]
        variance = physical_quantity - system_before
        item["quantity"] = physical_quantity
        status = "MATCH" if variance == 0 else ("SURPLUS" if variance > 0 else "SHORTAGE")
        self._log("RECONCILIATION", item=item_code, system_before=system_before,
                  physical=physical_quantity, variance=variance, reason=reason,
                  stock_after=item["quantity"])
        return {"item": item_code, "system_quantity": system_before,
                "physical_quantity": physical_quantity, "variance": variance,
                "status": status}
