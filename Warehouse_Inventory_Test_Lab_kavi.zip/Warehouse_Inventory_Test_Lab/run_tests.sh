#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
python3 run_tests.py "$@"
