#!/usr/bin/env python3
"""
Runs every test case, prints a pass/fail table and writes
results/Test_Execution_Report.csv (the filled-in execution report).

Usage:
    python run_tests.py
    python run_tests.py --tester "Your Name"
"""
import argparse
import csv
import os
import re
import sys
import unittest
from collections import OrderedDict
from datetime import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
CASES_CSV = os.path.join(ROOT, "test_cases", "Test_Cases.csv")
REPORT_CSV = os.path.join(ROOT, "results", "Test_Execution_Report.csv")
TESTS_DIR = os.path.join(ROOT, "tests")
ID_RE = re.compile(r"^test_([A-Z]{2})_(\d{2})_")


class Recorder(unittest.TestResult):
    """Remembers the outcome of every test, keyed by test case ID (e.g. SD-01)."""

    def __init__(self):
        super().__init__()
        self.outcomes = OrderedDict()
        self.duplicates = []

    @staticmethod
    def case_id(test):
        match = ID_RE.match(test._testMethodName)
        return "%s-%s" % match.groups() if match else test._testMethodName

    def _store(self, test, status, message=""):
        key = self.case_id(test)
        if key in self.outcomes:
            self.duplicates.append(key)
        self.outcomes[key] = (status, message)

    def addSuccess(self, test):
        super().addSuccess(test)
        self._store(test, "Pass")

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self._store(test, "Fail", str(err[1]).splitlines()[0] if str(err[1]) else "Assertion failed")

    def addError(self, test, err):
        super().addError(test, err)
        self._store(test, "Fail", "%s: %s" % (err[0].__name__, err[1]))


def load_cases():
    with open(CASES_CSV, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main():
    parser = argparse.ArgumentParser(description="Run the warehouse inventory test cases")
    parser.add_argument("--tester", default="", help="name to write in the 'Executed By' column")
    args = parser.parse_args()

    cases = load_cases()
    suite = unittest.defaultTestLoader.discover(TESTS_DIR, pattern="test_*.py")
    recorder = Recorder()
    suite.run(recorder)

    catalog_ids = [c["Test Case ID"] for c in cases]
    extra = [i for i in recorder.outcomes if i not in catalog_ids]
    run_time = datetime.now().strftime("%Y-%m-%d %H:%M")

    print("=" * 78)
    print(" WAREHOUSE INVENTORY APPLICATION - TEST EXECUTION")
    print(" Run on: %s" % run_time)
    print("=" * 78)
    print("%-6s %-22s %-42s %s" % ("ID", "Module", "Test case", "Result"))
    print("-" * 78)

    rows = []
    totals = OrderedDict()
    for case in cases:
        tid, module = case["Test Case ID"], case["Module"]
        status, message = recorder.outcomes.get(tid, ("Not Run", "No automated test found for this ID"))
        if status == "Pass":
            actual = "As expected: " + case["Expected Result"]
        else:
            actual = message
        rows.append({
            "Test Case ID": tid, "Module": module, "Title": case["Title"],
            "Executed By": args.tester, "Execution Date": run_time,
            "Actual Result": actual, "Status": status,
            "Defect ID": "", "Remarks": "" if status == "Pass" else message,
        })
        stats = totals.setdefault(module, {"Pass": 0, "Fail": 0, "Not Run": 0})
        stats[status] += 1
        print("%-6s %-22s %-42s %s" % (tid, module[:22], case["Title"][:42], status.upper()))

    print("-" * 78)
    print("%-24s %6s %6s %6s %6s" % ("Module", "Total", "Pass", "Fail", "NotRun"))
    grand = {"Pass": 0, "Fail": 0, "Not Run": 0}
    for module, stats in totals.items():
        print("%-24s %6d %6d %6d %6d" % (module, sum(stats.values()), stats["Pass"],
                                         stats["Fail"], stats["Not Run"]))
        for key in grand:
            grand[key] += stats[key]
    total = sum(grand.values())
    print("-" * 78)
    print("%-24s %6d %6d %6d %6d" % ("TOTAL", total, grand["Pass"], grand["Fail"], grand["Not Run"]))
    rate = 100.0 * grand["Pass"] / total if total else 0.0
    print("Pass rate: %.1f%%" % rate)

    if extra:
        print("WARNING: tests without a catalog entry: %s" % ", ".join(extra))
    if recorder.duplicates:
        print("WARNING: duplicate test IDs: %s" % ", ".join(sorted(set(recorder.duplicates))))

    os.makedirs(os.path.dirname(REPORT_CSV), exist_ok=True)
    with open(REPORT_CSV, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("Execution report saved to: results/Test_Execution_Report.csv")
    print("RESULT: %s" % ("ALL TEST CASES PASSED" if grand["Fail"] == 0 and grand["Not Run"] == 0
                          else "SOME TEST CASES FAILED / NOT RUN"))
    return 0 if grand["Fail"] == 0 and grand["Not Run"] == 0 and not extra else 1


if __name__ == "__main__":
    sys.exit(main())
